﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading; // easy access to allow pausing (Thread.Sleep)

namespace KellyJames
{
    class Game
    {
        //declare game variables
        // int for which character to select from input
        int curSelection = -1;
        // character that will be doing the attacking this turn
        Character Attacker = null;
        // character that will be defending this turn
        Character Defender = null;
        // random number generator for NPC turns
        Random rng = new Random();

        // bool to determine if it's the player's turn
        bool playerTurn = true;

        // array of characters for player
        Player[] playerArray;
        // array of characters for rival
        Enemy[] rivalArray;  
        public  void Init()
        {
            // fill the player party array with 3 Players filled out with use of the overloaded constructor
            playerArray = new Player[3];
            playerArray[0] = new Player("1", 10, 5);
            playerArray[1] = new Player("2", 10, 5);
            playerArray[2] = new Player("3", 10, 5);
            // fill the rival party array with 3 Enemies filled out with use of the overloaded constructor
            rivalArray = new Enemy[3];
            rivalArray[0] = new Enemy("A", 10, 5);
            rivalArray[1] = new Enemy("B", 10, 5);
            rivalArray[2] = new Enemy("C", 10, 5);
        }

        //returns false when game is over
        public bool Update()
        {
            // clears console for a fresh start
            Console.Clear();

            //branch who's turn it is and add a line indicating so
            if (playerTurn == true)  //switches between player and enemy.
            {
                //print that it's the player's turn
                Console.WriteLine("This is Players Turn");
                //print the current parties
                PrintParties();
                //run the player turn
                PlayerTurn();
            }
            else 
            {

                //print the rivals turn label
                Console.WriteLine("This is Rivals Turn");
               
                //print the current parties
                 PrintParties();
                
                //run the rivals turn
                 RivalsTurn();

            }

            //end game check
            return EndTurn();
        }

        void PlayerTurn()
        {
            // print instructions to select an attacker
            Console.WriteLine("Select an Attacker between 1-3");
            // Loop until an attacker is chosen
            while (Attacker == null)
            {
                // use num 1-3 to select player party member that is the attacker
                ConsoleKeyInfo k = Console.ReadKey();
                // start a new line after user input
                Console.WriteLine();

                // Data Validation: make sure the key typed is a valid key
                if (k.KeyChar < '1' || k.KeyChar > '3')
                {
                    //Repeat instructions if wrong key pressed
                    Console.WriteLine("You pressed the wrong key, between 1-3, try again.");
                    // loop again
                    continue;
                }
                else // convert from key input (1-3) to array element space (0-2)
                    curSelection = int.Parse(k.KeyChar.ToString()) - 1;
                //check to make sure the selected character is alive HP > 0
                if (playerArray[curSelection].GetHP() > 0)
                {
                    Attacker = playerArray[curSelection];
                    //print the attackers name
                    Console.WriteLine(Attacker.Name());
                    //assign the selected character as the attacker
                }
                else 
                {

                 Console.WriteLine("Character is Dead! You must try again!");

                }
            }

            //print instructions for choosing a rival.
            Console.WriteLine("Select your attack target between 1-3");
            //loop until a defender is choosen
            while (Defender == null)
            {
                // use 1-3 to select player party member that is the attacker
                ConsoleKeyInfo k = Console.ReadKey();

                //add a new line after the user input
                Console.WriteLine();

                // Data Validation: make sure the key typed is a valid key
                if (k.KeyChar < '1' || k.KeyChar > '3')
                {
                    // repeat instructions
                    Console.WriteLine("Wrong number, has to be between 1-3");
                    // loop again
                    continue;
                }
                else // convert from key input (1-3) to array element space (0-2)
                    curSelection = int.Parse(k.KeyChar.ToString()) - 1; //minus one to use as index

                //check to make sure the selected character is alive HP > 0
                if (rivalArray[curSelection].GetHP() > 0)
                {
                    Defender = rivalArray[curSelection];
                    //print the Defenders name
                    Console.WriteLine(Defender.Name());
                    //assign the selected character as the Defender
                }

                else
                {

                    Console.WriteLine("Character is Dead! You must try again!");

                }
            }
            //damage the defender by the attacker's Strength value
            Console.WriteLine("Select Attack Type: {0} Melee, {1} Magic Spell, {2) Heal");
            float dmg= 0;
            bool isMagic=false;
            while (true)
            {
                int selectAttack = int.Parse(Console.ReadKey().KeyChar.ToString());
                if (selectAttack == 0) //Melee
                {
                
                    dmg=Attacker.GetStrength();
                    break;
                }
                else if (selectAttack ==1) //Magic
                {

                    if (Attacker.GetMana() > 0)
                    {
                        Console.WriteLine("Choose a Spell from 1-5");
                        while (true)
                        {
                            int selectSpell = int.Parse(Console.ReadKey().KeyChar.ToString());
                            if (selectSpell <1 || selectSpell >5)
                            {
                                Console.WriteLine("You picked a wrong number, try again!");
                                continue;
                            }
                            else
                            {
                                if (Attacker.GetMana()> selectSpell)
                                {
                                    dmg = selectSpell;
                                    Attacker.DepleteMana(selectSpell);
                                    isMagic = true;
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("You don't have enough Mana for this Spell, try again");
                                    continue;
                                }
                            }
                        }
                    }

                }
                else if (selectAttack ==2)
                {
                    Attacker.CharacterHeal(3);
                    break;
                }

            }
            Console.BackgroundColor = Defender.GetTeamColor();
            if (isMagic)
            {
                for (int i = 0; i < rivalArray.Length; i++)
                {
                    rivalArray[i].ApplyDamage(dmg);
                    rivalArray[i].PrintStats();
                }
            }
            else
            {
                Defender.ApplyDamage(dmg);
                Defender.PrintStats();
            }
            
            Console.BackgroundColor = ConsoleColor.Black;
            
           
            //pause for 2 seconds
            Thread.Sleep(2000);

            //reset attacker/defender for next attack
            Attacker = null;
            Defender = null;
        }

        void RivalsTurn() //switch to rng instead of user input
        {
            // print instructions that the rival is choosing which character will attack
            Console.WriteLine("Rival is choosing which member will attack: ");
            // pause for 2 seconds
            Thread.Sleep(2000);

            // loop until a valid attacker is found
            while (Attacker == null)
            {
                // randomly select an attacker from the rival party
                curSelection = rng.Next(3); //assumes 3 party members

                // check if the attacker has health
                if (rivalArray[curSelection].GetHP() > 0)
                {
                    Attacker = rivalArray[curSelection];
                    //print the Attacker name
                    Console.WriteLine(Attacker.Name());
                    //assign the selected character as the Attacker
                }
              
            }

            //print that the rival is choosing which player member to attack
            Console.WriteLine("Rival is choosing which player to attack: ");

            // pause for 2 seconds
            Thread.Sleep(2000);
            // loop until a valid defender is found
            while (Defender == null)
            {
                // randomly choose a player's character
                curSelection = rng.Next(3); //assumes 3 party members

                // check if the player is alive
                if (playerArray[curSelection].GetHP() > 0)
                {
                    Defender = playerArray[curSelection];
                    //print the Defender name
                    Console.WriteLine(Defender.Name());
                    //assign the selected character as the Defender
                }
              
            }

            //damage the defender by the attacker's Strength value
            Defender.ApplyDamage(Attacker.GetStrength());
            //change color for rival team
            Console.BackgroundColor = ConsoleColor.DarkGray;

            //print the new player's health
            Defender.PrintStats();
            //change color back for normal
            
            Console.BackgroundColor = ConsoleColor.Black;
            //pause for 2 seconds
            Thread.Sleep(2000);

            //reset attacker/defender for next attack
            Attacker = null;
            Defender = null;
        }

        void PrintParties()
        {
            //change backround color for player team
            Console.BackgroundColor = playerArray[0].GetTeamColor();

            //print label for player's team
            Console.WriteLine("Player's Team");
            //loop through player party printing each character's stats
            for (int i = 0; i < playerArray.Length; i++)
            {
                playerArray[i].PrintStats();
            }
            //change background for rival team
            Console.BackgroundColor =rivalArray[0].GetTeamColor();
            //print label for rival team
            Console.WriteLine("Rivals Turn");
            //loop through rival party printing each character's stats
            for (int i = 0; i < rivalArray.Length; i++)
            {
                rivalArray[i].PrintStats();
            }
            //change backround color back to default
            
            Console.BackgroundColor = ConsoleColor.Black;
        }

        bool EndTurn()
        {
            //switch turns for next loop
            playerTurn = !playerTurn;

            // loop through players to see if they're alive and store in a variable counting if they're alive or not
            bool playersAlive = false;
            for (int i = 0; i < playerArray.Length; i++)
            {
                if (playerArray[i].GetHP()>0)
                {
                    playersAlive = true;
                }
            }
            // same for rivals
            bool rivalsAlive = false;
          
            for (int i = 0; i < rivalArray.Length; i++)
            {
                if (rivalArray[i].GetHP() > 0)
                {
                    rivalsAlive = true;
                }
            }
            // if both have things alive start the next round, pause the game, and return true to continue playing
            if (playersAlive && rivalsAlive)
            {
                Console.WriteLine("Next Round Starts in 5 seconds");
                Thread.Sleep(5000);
                return true;
            } // if only the players have members alive you win
            else if (playersAlive)
            {
                //clear screen for results
                Console.Clear();
                //print you've won and parties
                Console.WriteLine("Congrats you win! Final Standings:");
                PrintParties();
                return false;
            } // only rival members are alive
            else
            {
                //clear screen for results
                Console.Clear();
                //Print you've lost and parties
                Console.WriteLine("You Lose :( Final Standings:");
                PrintParties();
                return false;
            }
        }
    }
}
