﻿using System;

namespace KellyJames
{
    class Program
    {
        static void Main(string[] args)
        {
            Game g = new Game();
            g.Init();
            //loop until game returns false
            while (g.Update())
            {
                //game is running
            }
        }
    }
}
