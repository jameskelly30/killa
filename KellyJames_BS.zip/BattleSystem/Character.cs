﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KellyJames
{
    //character with stats derives from object to have a name
   public  class Character
    {
        
        protected string name = "Default";
        protected float HPMax = 10;
        protected float HP = 10;
        protected float Strength = 3;

        protected int maxSpells = 5;
        protected float[] magicSpells = { 1, 2, 3, 4, 5 };
        protected int mana = 15;
        public string Name()
        {
            return name;
        }


        // Accessor/Getter for the current hit points
        public float GetHP()
        {
            return HP;
        }

        // Accessor/Getter for the attack points
        public float GetStrength()
        {
            return Strength;
        }

        // Modifying the health by subtracting the damage passed in


        public void ApplyDamage(float damage)
        {
            HP -= damage;
            HP = MathF.Max(0, HP); //prevents health below 0
        }
        public void CharacterHeal(float health)
        {
            HP += health;
            HP = MathF.Min(HPMax, HP); //Makes input never go above maximum
        }
        public int GetMana() 
       {
           return mana;

        }

        public void DepleteMana(float _spellCost)
        {
            mana -= (int)_spellCost;
        }
        // Prints the different stats in a readable output, changes color to 
        // green when full health, yellow for damaged, and black for dead
        public void PrintStats()
        {
            string output = "";
            output += name;
            output += " HP:" + HP;
            output += " Strength:" + Strength;

            //end the line after each character
            output += "\n";
            // change background color based on health
            if (HP == HPMax)//full health
                Console.ForegroundColor = ConsoleColor.Green;
            else if (HP > 0)// partial health
                Console.ForegroundColor = ConsoleColor.Yellow;
            else// no health
                Console.ForegroundColor = ConsoleColor.Black;
            
            Console.Write(output);
            //reset color after
            Console.ForegroundColor = ConsoleColor.White;
        }


        //virtual so children can override
        public virtual ConsoleColor GetTeamColor()
        {
            return ConsoleColor.Black;
        }

    }


    public class Player : Character
    {
        //Override with the player's team color
        public override ConsoleColor GetTeamColor()
        {
            return ConsoleColor.DarkBlue;
        }

        // overloaded constructor
        public Player(string _n, float _HP, float _A)
        {
            name = _n;
            HPMax = _HP;
            HP = HPMax;
            Strength = _A;
        }
    }

    public class Enemy : Character
    {
        public override ConsoleColor GetTeamColor()
        {
            return ConsoleColor.DarkRed;
        }
        

        //public void DepleteMana(float _spellCost)                          //COULD NOT GET THIS LINE OF CODE TO WORK 115-120.
        //{
        //    mana  -= (int)_spellCost;
        // }
        
        // overloaded constructor
        public Enemy(string _n, float _HP, float _A)
        {
            name = _n;
            HPMax = _HP;
            HP = HPMax;
            Strength = _A;
            magicSpells = new float[maxSpells];
            for (int i = 0; i <magicSpells.Length; i++)
            {
                magicSpells[i] = i + i;
            }

        }
    }
}
